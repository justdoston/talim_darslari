#!/bin/bash

echo "[+] Setting up CTF lab environment..."

# ---------- Create systemd service ----------
SERVICE_FILE="/etc/systemd/system/ctfserver.service"

echo "[+] Creating systemd service..."

cat > $SERVICE_FILE <<EOF
[Unit]
Description=CTF UDP Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /home/alex/server.py
Restart=always
User=root

[Install]
WantedBy=multi-user.target
EOF

# ---------- Enable service ----------
echo "[+] Enabling server service..."

systemctl daemon-reload
systemctl enable ctfserver
systemctl start ctfserver

# ---------- Create sudo rule ----------
echo "[+] Configuring sudo permissions (lab mode)..."

SUDO_FILE="/etc/sudoers.d/ctf_lab"

cat > $SUDO_FILE <<EOF
%students ALL=(ALL) NOPASSWD: /usr/bin/cat
EOF

chmod 440 $SUDO_FILE

# ---------- Ensure students group exists ----------
if ! getent group students >/dev/null; then
    groupadd students
fi

echo "[+] Setup completed!"
