import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", 123))

while True:
    data, addr = sock.recvfrom(1024)
    sock.sendto(b"alex:TXpVMVpHTmhPVEpqT1RabU9XVmhPVGN5TnpNd1pUY3lPVFpsTkRJd00yVmpOMlUzWmpZNE13bz0K", addr)
