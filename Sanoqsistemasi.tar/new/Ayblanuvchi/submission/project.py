#!/usr/bin/env python3
#1
print("Bulardan biri virus")
