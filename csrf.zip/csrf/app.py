from flask import Flask, render_template, request, redirect, session, url_for
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "supersecretkey"
DATABASE = "users.db"


# ------------------------
# Database Helpers
# ------------------------

def get_db():
    return sqlite3.connect(DATABASE, timeout=10)


def init_db():
    with get_db() as conn:
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL
            )
        """)

        # Create default admin account if not exists
        c.execute("SELECT id FROM users WHERE email=?", ("director@academy.local",))
        if not c.fetchone():
            hashed_pw = generate_password_hash("SuperSecure123!")
            c.execute(
                "INSERT INTO users (email, password, role) VALUES (?, ?, ?)",
                ("director@academy.local", hashed_pw, "admin")
            )
        conn.commit()


# ------------------------
# Routes
# ------------------------

@app.route("/")
def index():
    return render_template("index.html")


# -------- Register --------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        hashed_pw = generate_password_hash(password)

        try:
            with get_db() as conn:
                c = conn.cursor()
                c.execute(
                    "INSERT INTO users (email, password, role) VALUES (?, ?, ?)",
                    (email, hashed_pw, "user")
                )
                conn.commit()
        except sqlite3.IntegrityError:
            return "Email already exists!"

        return redirect(url_for("login"))

    return render_template("register.html")


# -------- Login --------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        with get_db() as conn:
            c = conn.cursor()
            c.execute("SELECT * FROM users WHERE email=?", (email,))
            user = c.fetchone()

        if user and check_password_hash(user[2], password):
            session["user_id"] = user[0]
            session["email"] = user[1]
            session["role"] = user[3]
            return redirect(url_for("dashboard"))

        return "Invalid credentials"

    return render_template("login.html")


# -------- Dashboard --------
@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))

    return render_template(
        "dashboard.html",
        email=session["email"],
        role=session["role"]
    )


# -------- Change Password --------
@app.route("/change-password", methods=["GET", "POST"])
def change_password():
    if "user_id" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        new_password = request.form.get("password")
        hashed_pw = generate_password_hash(new_password)

        with get_db() as conn:
            c = conn.cursor()
            c.execute(
                "UPDATE users SET password=? WHERE id=?",
                (hashed_pw, session["user_id"])
            )
            conn.commit()

        return "Password changed successfully!"

    return render_template("change_password.html")


# -------- Admin Secret --------
@app.route("/admin/secret")
def admin_secret():
    if "user_id" not in session:
        return redirect(url_for("login"))

    if session.get("role") != "admin":
        return "Access denied!"

    return """
    <h2>🎉 ADMIN ACCESS GRANTED 🎉</h2>
    <p>FLAG{csrf_account_takeover_master}</p>
    """


# -------- Run App --------
if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
